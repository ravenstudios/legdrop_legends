# Game Title

## To-Do
- [ ] Add music and sounds
- [ ] Add attack animation and screen shake
- [ ] Add dialog
- [ ] Dice rolls for injuries
- [ ] Pin mechanics with mini game that relies on enemy health
- [ ] Load new maps for worlds and in buildings
- [ ] Need company name
- [ ] Training
- [ ] Ref


## Ideas

- Add Angel, fat guy with just trunks and very small wings
- Car ride cut scenes
- You play as the manager and collect wrestlers
- Submissions are how you capture
- Start training then indys then big show then world
- Major and min injurys, minor loose turn, major lose match
- Manager specials like brass nucks and distract ref
- Low blows
- Heel and face class that your decisons dictate and will have de-buffs and buffs

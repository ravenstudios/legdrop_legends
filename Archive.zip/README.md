# Legdrop Legends
Python Pygame Pokemon like game with wrestliing

To run:
```
git clone https://github.com/ravenstudios/legdrop_legends.git
```
```
cd legdrop_legends
```
```
python3 src/main.py
```

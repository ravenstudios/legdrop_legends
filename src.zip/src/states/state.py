class State():
    def __init__(self):
        pass
    def events(self, events=None):
        pass
    def update(self):
        pass
    def draw(self, surface):
        pass
